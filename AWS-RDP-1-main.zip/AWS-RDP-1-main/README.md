<a href="https://github.com/chinotechtools/AWS-RDP"><img src="https://img.shields.io/badge/AWS-RDP-blue"></a>

# Windows2019 AWS-RDP-US

Create a free VPS with 2cpu-7gb Ram FREE with Github:

+ Click Fork in the right corner of the screen to save it to your Github.
+ Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
+ In Github go to Settings> Secrets> New repository secret
+ In Name: enter NGROK_AUTH_TOKEN
+ In Value: visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste Your Authtoken into
+ Press Add secret
+ Go to Action> AWS-RDP> Run workflow
+ Reload the page and press AWS-RDP> build
+ Press the down arrow on Connect To Your RPD to get IP, User, Password.

+ IF MY REPO GOT DELETED,ON YOUR GITHUB GO TO .github/workflows > main.yml AND EDIT NEW LINK TO YOUR REPO. Include ALL Prerequisite in Files FOLDER
#### ɴᴏ ɪʟʟᴇɢᴀʟ ᴀᴄᴛɪᴠɪᴛɪᴇs ᴀʟʟᴏᴡᴇᴅ

### Watch Video Guide Here 
<a href="https://chinotechtips.blogspot.com/2021/07/how-to-create-free-rdp-with-github.html"><img src="https://img.shields.io/badge/VIDEO-GUIDE-red"></a>
